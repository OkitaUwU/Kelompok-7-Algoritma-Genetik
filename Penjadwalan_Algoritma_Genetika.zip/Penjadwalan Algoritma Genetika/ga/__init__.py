"""Paket Algoritma Genetika untuk penjadwalan kuliah (tahap UTS)."""
