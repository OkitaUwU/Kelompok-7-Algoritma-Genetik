"""Operator genetika yang ditulis sendiri (tanpa library AG)."""


def random_gene(data, rng):
    return (rng.randrange(data.n_slots), rng.randrange(data.n_rooms))


def random_chromosome(data, rng):
    return [random_gene(data, rng) for _ in data.courses]


def init_population(data, size, rng):
    return [random_chromosome(data, rng) for _ in range(size)]


# ---------------------------------------------------------------- seleksi
def select_roulette(pop, fit, rng):
    """Roulette wheel: peluang terpilih sebanding dengan fitness."""
    total = sum(fit)
    pick = rng.random() * total
    acc = 0.0
    for ind, f in zip(pop, fit):
        acc += f
        if acc >= pick:
            return ind
    return pop[-1]


def select_tournament(pop, fit, rng, k=3):
    """Turnamen: ambil k individu acak, pilih yang fitness-nya tertinggi."""
    idx = [rng.randrange(len(pop)) for _ in range(k)]
    return pop[max(idx, key=lambda i: fit[i])]


# -------------------------------------------------------------- crossover
def crossover_one_point(p1, p2, rng):
    """Satu titik: ekor kedua induk ditukar mulai dari titik potong acak."""
    cut = rng.randrange(1, len(p1))
    return p1[:cut] + p2[cut:], p2[:cut] + p1[cut:]


def crossover_uniform(p1, p2, rng):
    """Uniform: tiap gen diwarisi dari salah satu induk dengan peluang 0,5."""
    c1, c2 = [], []
    for a, b in zip(p1, p2):
        if rng.random() < 0.5:
            c1.append(a)
            c2.append(b)
        else:
            c1.append(b)
            c2.append(a)
    return c1, c2


# ----------------------------------------------------------------- mutasi
def mutate(ch, data, pm, rng):
    """Mutasi acak: tiap gen diganti (slot, ruang) baru dengan peluang pm."""
    return [random_gene(data, rng) if rng.random() < pm else gene for gene in ch]


SELEKSI = {"roulette": select_roulette, "turnamen": select_tournament}
CROSSOVER = {"satu_titik": crossover_one_point, "uniform": crossover_uniform}
