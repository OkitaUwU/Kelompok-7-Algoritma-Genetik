"""Fungsi fitness berbasis penalti pelanggaran kendala keras (H1-H4).

Kromosom: list berisi pasangan (slot, ruang) untuk tiap sesi kuliah.
fitness = 1 / (1 + total pelanggaran keras)
"""
from collections import Counter


def _pairs(counter):
    """Jumlah pasangan sesi yang bentrok: tiap kunci dengan n sesi menghasilkan n(n-1)/2 pasangan."""
    return sum(n * (n - 1) // 2 for n in counter.values())


def hard_breakdown(ch, data):
    """Kembalikan (H1, H2, H3, H4).

    H1: pasangan sesi dengan dosen sama pada slot sama
    H2: pasangan sesi pada ruang dan slot sama
    H3: pasangan sesi dengan kelas mahasiswa sama pada slot sama
    H4: sesi dengan jumlah peserta melebihi kapasitas ruang
    """
    dosen, ruang, kelas = Counter(), Counter(), Counter()
    h4 = 0
    for g, (slot, room) in enumerate(ch):
        c = data.courses[g]
        dosen[(c.lecturer.id, slot)] += 1
        ruang[(room, slot)] += 1
        kelas[(c.group, slot)] += 1
        if c.students > data.rooms[room].capacity:
            h4 += 1
    return _pairs(dosen), _pairs(ruang), _pairs(kelas), h4


def hard_violations(ch, data):
    return sum(hard_breakdown(ch, data))


def fitness(ch, data):
    return 1.0 / (1.0 + hard_violations(ch, data))


def soft_info(ch, data):
    """Informasi kendala lunak (hanya dilaporkan, belum dioptimalkan pada UTS).

    S1: jumlah sesi pada slot yang dihindari dosen
    S2: jumlah slot kosong di antara sesi pertama dan terakhir tiap kelas pada satu hari
    """
    s1 = 0
    jam_per_kelas = {}
    for g, (slot, _room) in enumerate(ch):
        c = data.courses[g]
        if slot in c.lecturer.avoid_slots:
            s1 += 1
        jam_per_kelas.setdefault((c.group, slot // 5), set()).add(slot % 5)
    s2 = sum((max(j) - min(j) + 1) - len(j) for j in jam_per_kelas.values())
    return s1, s2
