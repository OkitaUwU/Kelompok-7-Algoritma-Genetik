"""Loop evolusi Algoritma Genetika dasar (tahap UTS)."""
import random
from dataclasses import dataclass

from .fitness import fitness, hard_violations
from .operators import CROSSOVER, SELEKSI, init_population, mutate


@dataclass
class Params:
    pop_size: int = 100
    generations: int = 100
    pc: float = 0.8          # peluang crossover
    pm: float = 0.05         # peluang mutasi per gen
    seleksi: str = "turnamen"
    crossover: str = "uniform"
    elitism: int = 2         # jumlah individu terbaik yang disalin langsung
    tournament_k: int = 3


@dataclass
class Result:
    best: list
    best_fitness: float
    best_violations: int
    first_valid_gen: int     # generasi pertama dengan jadwal valid (None bila tidak ada)
    best_history: list       # fitness terbaik per generasi (indeks 0 = populasi awal)
    avg_history: list        # fitness rata-rata populasi per generasi


def run_ga(data, params, seed):
    rng = random.Random(seed)
    select = SELEKSI[params.seleksi]
    cross = CROSSOVER[params.crossover]

    def pilih(pop, fit):
        if params.seleksi == "turnamen":
            return select(pop, fit, rng, params.tournament_k)
        return select(pop, fit, rng)

    pop = init_population(data, params.pop_size, rng)
    best, best_fit = None, -1.0
    best_hist, avg_hist = [], []
    first_valid = None

    for gen in range(params.generations + 1):
        fit = [fitness(ind, data) for ind in pop]
        order = sorted(range(len(pop)), key=lambda i: fit[i], reverse=True)
        if fit[order[0]] > best_fit:
            best, best_fit = pop[order[0]][:], fit[order[0]]
        if first_valid is None and best_fit == 1.0:
            first_valid = gen
        best_hist.append(best_fit)
        avg_hist.append(sum(fit) / len(fit))
        if gen == params.generations:
            break

        # elitisme: salin individu terbaik tanpa perubahan
        baru = [pop[i][:] for i in order[:params.elitism]]
        while len(baru) < params.pop_size:
            p1, p2 = pilih(pop, fit), pilih(pop, fit)
            if rng.random() < params.pc:
                c1, c2 = cross(p1, p2, rng)
            else:
                c1, c2 = p1[:], p2[:]
            baru.append(mutate(c1, data, params.pm, rng))
            if len(baru) < params.pop_size:
                baru.append(mutate(c2, data, params.pm, rng))
        pop = baru

    return Result(best, best_fit, hard_violations(best, data),
                  first_valid, best_hist, avg_hist)
