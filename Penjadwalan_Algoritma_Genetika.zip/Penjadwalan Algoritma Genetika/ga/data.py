"""Pemuatan data: mata kuliah, dosen, dan ruang dari berkas CSV."""
import csv
import os
from dataclasses import dataclass, field

JUMLAH_HARI = 5
SLOT_PER_HARI = 5
JUMLAH_SLOT = JUMLAH_HARI * SLOT_PER_HARI  # 25

NAMA_HARI = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat"]
JAM_SLOT = ["07.30-09.10", "09.20-11.00", "11.10-12.50", "13.30-15.10", "15.20-17.00"]


@dataclass
class Lecturer:
    id: str
    avoid_slots: set = field(default_factory=set)


@dataclass
class Room:
    name: str
    capacity: int


@dataclass
class Course:
    code: str
    name: str
    lecturer: Lecturer
    group: str
    students: int
    short: str = ""
    sks: int = 0
    semester: str = ""
    kelas: str = ""


@dataclass
class Data:
    courses: list
    rooms: list
    lecturers: dict

    @property
    def n_slots(self):
        return JUMLAH_SLOT

    @property
    def n_rooms(self):
        return len(self.rooms)


def slot_label(slot):
    """Ubah indeks slot (0..24) menjadi (nama hari, nomor jam ke-1..5, rentang jam)."""
    hari, jam = divmod(slot, SLOT_PER_HARI)
    return NAMA_HARI[hari], jam + 1, JAM_SLOT[jam]


def load_data(folder="data"):
    lecturers = {}
    with open(os.path.join(folder, "dosen.csv"), encoding="utf-8") as f:
        for row in csv.DictReader(f):
            avoid = {int(x) for x in row["slot_dihindari"].split(";") if x.strip()}
            lecturers[row["dosen"]] = Lecturer(row["dosen"], avoid)

    rooms = []
    with open(os.path.join(folder, "ruang.csv"), encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rooms.append(Room(row["ruang"], int(row["kapasitas"])))

    courses = []
    with open(os.path.join(folder, "matkul.csv"), encoding="utf-8") as f:
        for row in csv.DictReader(f):
            courses.append(Course(row["kode"], row["nama"], lecturers[row["dosen"]],
                                  f"{row['semester']}-{row['kelas']}", int(row["peserta"]), row["singkat"],
                                  int(row.get("sks") or 0), row["semester"], row["kelas"]))
    return Data(courses, rooms, lecturers)
