"""Membuat diagram alir AG dasar (hasil/diagram_alir.png)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon

fig, ax = plt.subplots(figsize=(6.4, 4.6))
ax.set_xlim(0, 12); ax.set_ylim(0, 9); ax.axis("off")
BW, BH = 4.2, 0.62


def box(x, y, text, rounded=True, w=BW):
    ax.add_patch(FancyBboxPatch((x - w/2, y - BH/2), w, BH,
                 boxstyle="round,pad=0.02,rounding_size=%s" % (0.3 if rounded else 0.04),
                 fc="#EAF1FB", ec="#1F4E79", lw=1.1))
    ax.text(x, y, text, ha="center", va="center", fontsize=7.6)


def arrow(p, q, text=None, tpos=None):
    ax.annotate("", xy=q, xytext=p, arrowprops=dict(arrowstyle="-|>", color="#333", lw=1.0))
    if text:
        ax.text(*tpos, text, fontsize=7.4, color="#C00000", ha="center", va="center")


def line(p, q):
    ax.plot([p[0], q[0]], [p[1], q[1]], color="#333", lw=1.0)

L, R = 2.6, 9.3
left = [(8.3, "Mulai", True), (7.2, "Muat data dan parameter", False),
        (6.1, "Inisialisasi populasi acak", False), (5.0, "Hitung fitness, catat terbaik", False)]
for y, t, r in left:
    box(L, y, t, r)
for a, b in zip(left, left[1:]):
    arrow((L, a[0] - BH/2), (L, b[0] + BH/2))

# belah ketupat keputusan
dy = 3.55
ax.add_patch(Polygon([(L, dy + .55), (L + 1.9, dy), (L, dy - .55), (L - 1.9, dy)],
                     fc="#FFF4D6", ec="#7F6000", lw=1.1))
ax.text(L, dy, "Generasi maksimum?", ha="center", va="center", fontsize=7.4)
arrow((L, 5.0 - BH/2), (L, dy + .55))
box(L, 2.1, "Keluarkan jadwal terbaik", False)
box(L, 1.0, "Selesai", True)
arrow((L, dy - .55), (L, 2.1 + BH/2), "Ya", (L + .35, 2.85))
arrow((L, 2.1 - BH/2), (L, 1.0 + BH/2))

right = [(3.55, "Elitisme (2 terbaik disalin)"), (4.65, "Seleksi: roulette / turnamen"),
         (5.75, "Crossover (peluang pc)"), (6.85, "Mutasi (peluang pm per gen)"),
         (7.95, "Populasi baru terbentuk")]
for y, t in right:
    box(R, y, t, False)
arrow((L + 1.9, dy), (R - BW/2, 3.55), "Tidak", (5.0, 3.8))
for a, b in zip(right, right[1:]):
    arrow((R, a[0] + BH/2), (R, b[0] - BH/2))
# garis kembali ke "Hitung fitness"
xm = 5.55
line((R - BW/2, 7.95), (xm, 7.95)); line((xm, 7.95), (xm, 5.0))
arrow((xm, 5.0), (L + BW/2, 5.0))
ax.text(xm + .15, 6.5, "generasi + 1", fontsize=7, rotation=90, va="center", color="#555")
plt.savefig("hasil/diagram_alir.png", dpi=220, bbox_inches="tight", pad_inches=0.05)
