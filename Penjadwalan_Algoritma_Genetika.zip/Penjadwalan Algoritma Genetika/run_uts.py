"""Pengujian awal UTS: 4 kombinasi (seleksi x crossover) x 10 run (seed 1-10).

Keluaran (folder hasil/):
  ringkasan_run.csv      hasil tiap run
  ringkasan_kombinasi.csv rekap per kombinasi
  jadwal_terbaik.csv     daftar sesi jadwal terbaik
  jadwal_hari_slot.csv   tabel hari x slot
  jadwal_terbaik.xlsx    semua tabel di atas + jadwal per kelas
  konvergensi.png, konvergensi_utama.png   grafik konvergensi
  ringkasan.json         angka-angka ringkas untuk laporan
"""
import json
import os
import statistics as st
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from ga.data import JAM_SLOT, NAMA_HARI, load_data, slot_label
from ga.engine import Params, run_ga
from ga.fitness import hard_breakdown, soft_info

SEEDS = list(range(1, 11))
KOMBINASI = [("roulette", "satu_titik"), ("roulette", "uniform"),
             ("turnamen", "satu_titik"), ("turnamen", "uniform")]
OUT = "hasil"


def jadwal_tabel(ch, data):
    rows = []
    for g, (slot, room) in enumerate(ch):
        c = data.courses[g]
        hari, jam, rentang = slot_label(slot)
        rows.append({"Hari": hari, "Slot": jam, "Jam": rentang, "Ruang": data.rooms[room].name,
                     "Semester": c.semester, "Kelas": c.kelas, "Kode": c.code, "Mata Kuliah": c.name,
                     "Singkatan": c.short, "SKS": c.sks, "Dosen": c.lecturer.id, "Peserta": c.students,
                     "Kapasitas": data.rooms[room].capacity, "_slot": slot, "_grp": c.group})
    df = pd.DataFrame(rows).sort_values(["_slot", "Ruang"]).reset_index(drop=True)
    return df


def grid_hari_slot(df, sep="\n"):
    grid = pd.DataFrame("", index=[f"Slot {i+1} ({JAM_SLOT[i]})" for i in range(5)], columns=NAMA_HARI)
    for _, r in df.iterrows():
        item = f"{r['Singkatan']} ({r['_grp']},{r['Ruang']})"
        cur = grid.iloc[r["Slot"] - 1, NAMA_HARI.index(r["Hari"])]
        grid.iloc[r["Slot"] - 1, NAMA_HARI.index(r["Hari"])] = cur + (sep if cur else "") + item
    return grid


def main():
    os.makedirs(OUT, exist_ok=True)
    data = load_data("data")
    runs, hist = [], {}
    results = {}
    for sel, cr in KOMBINASI:
        key = f"{sel}+{cr}"
        hist[key] = {"best": [], "avg": []}
        for seed in SEEDS:
            t0 = time.time()
            r = run_ga(data, Params(seleksi=sel, crossover=cr), seed)
            results[(key, seed)] = r
            hist[key]["best"].append(r.best_history)
            hist[key]["avg"].append(r.avg_history)
            runs.append({"kombinasi": key, "seleksi": sel, "crossover": cr, "seed": seed,
                         "fitness_terbaik": r.best_fitness, "pelanggaran_keras": r.best_violations,
                         "generasi_valid_pertama": r.first_valid_gen,
                         "fitness_rata2_populasi_akhir": r.avg_history[-1],
                         "waktu_detik": round(time.time() - t0, 3)})
    df_run = pd.DataFrame(runs)
    df_run.to_csv(f"{OUT}/ringkasan_run.csv", index=False)

    rekap = []
    for key, g in df_run.groupby("kombinasi", sort=False):
        fv = g["generasi_valid_pertama"].dropna()
        rekap.append({"kombinasi": key,
                      "run_valid": f"{int(g['pelanggaran_keras'].eq(0).sum())}/{len(g)}",
                      "fitness_terbaik": g["fitness_terbaik"].max(),
                      "fitness_rata2": g["fitness_terbaik"].mean(),
                      "gen_valid_rata2": fv.mean(), "gen_valid_sd": fv.std(ddof=1),
                      "gen_valid_min": fv.min(), "gen_valid_maks": fv.max()})
    df_rekap = pd.DataFrame(rekap)
    df_rekap.to_csv(f"{OUT}/ringkasan_kombinasi.csv", index=False)

    # konfigurasi utama: run valid terbanyak, lalu generasi valid rata-rata terkecil
    utama = sorted(rekap, key=lambda r: (-int(r["run_valid"].split("/")[0]), r["gen_valid_rata2"]))[0]["kombinasi"]
    best_seed = min(SEEDS, key=lambda s: (-results[(utama, s)].best_fitness,
                                          results[(utama, s)].first_valid_gen or 10**9, s))
    best = results[(utama, best_seed)]
    df_j = jadwal_tabel(best.best, data)
    grid = grid_hari_slot(df_j)
    s1, s2 = soft_info(best.best, data)
    hb = hard_breakdown(best.best, data)

    df_j.drop(columns=["_slot", "_grp"]).to_csv(f"{OUT}/jadwal_terbaik.csv", index=False, encoding="utf-8-sig")
    grid_hari_slot(df_j, sep=" | ").to_csv(f"{OUT}/jadwal_hari_slot.csv", encoding="utf-8-sig")
    with pd.ExcelWriter(f"{OUT}/jadwal_terbaik.xlsx", engine="openpyxl") as xw:
        df_j.drop(columns=["_slot", "_grp"]).to_excel(xw, sheet_name="Daftar Sesi", index=False)
        grid.to_excel(xw, sheet_name="Hari x Slot")
        for kls in sorted(df_j["_grp"].unique()):
            sub = df_j[df_j["_grp"] == kls].drop(columns=["_slot", "_grp"])
            sub.to_excel(xw, sheet_name=f"Sem {kls}", index=False)
        df_run.to_excel(xw, sheet_name="Ringkasan Run", index=False)
        df_rekap.to_excel(xw, sheet_name="Ringkasan Kombinasi", index=False)
        for ws in xw.book.worksheets:
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width = min(
                    42, max(len(str(c.value or "").split("\n")[0]) for c in col) + 2)

    # grafik 1: rata-rata fitness terbaik per generasi, 4 kombinasi
    plt.figure(figsize=(7, 3.8))
    for key, h in hist.items():
        n = len(h["best"])
        mean = [sum(x[i] for x in h["best"]) / n for i in range(len(h["best"][0]))]
        plt.plot(mean, label=key.replace("+", " + ").replace("_", " "), linewidth=1.8)
    plt.xlabel("Generasi"); plt.ylabel("Fitness terbaik (rata-rata 10 run)")
    plt.title("Konvergensi fitness terbaik per kombinasi operator")
    plt.grid(alpha=.3); plt.legend(fontsize=8); plt.tight_layout()
    plt.savefig(f"{OUT}/konvergensi.png", dpi=200); plt.close()

    # grafik 2: konfigurasi utama, fitness terbaik (rata-rata + rentang) dan rata-rata populasi
    h = hist[utama]; G = len(h["best"][0]); n = len(h["best"])
    mb = [sum(x[i] for x in h["best"]) / n for i in range(G)]
    lo = [min(x[i] for x in h["best"]) for i in range(G)]
    hi = [max(x[i] for x in h["best"]) for i in range(G)]
    ma = [sum(x[i] for x in h["avg"]) / n for i in range(G)]
    plt.figure(figsize=(7, 3.8))
    plt.fill_between(range(G), lo, hi, alpha=.2, label="Rentang fitness terbaik (min-maks)")
    plt.plot(mb, linewidth=2, label="Fitness terbaik (rata-rata)")
    plt.plot(ma, linewidth=1.8, linestyle="--", label="Fitness rata-rata populasi")
    plt.xlabel("Generasi"); plt.ylabel("Fitness")
    plt.title(f"Konvergensi konfigurasi utama ({utama.replace('+', ' + ').replace('_', ' ')})")
    plt.grid(alpha=.3); plt.legend(fontsize=8, loc="lower right"); plt.tight_layout()
    plt.savefig(f"{OUT}/konvergensi_utama.png", dpi=200); plt.close()

    ring = {"utama": utama, "seed_terbaik": best_seed, "H1_H4": hb, "S1": s1, "S2": s2,
            "rekap": rekap, "run_utama": df_run[df_run.kombinasi == utama].to_dict("records"),
            "gen_valid_utama": [results[(utama, s)].first_valid_gen for s in SEEDS]}
    with open(f"{OUT}/ringkasan.json", "w", encoding="utf-8") as f:
        json.dump(ring, f, indent=1, default=float)

    pd.set_option("display.width", 200)
    print(df_rekap.to_string(index=False))
    print("\nKonfigurasi utama:", utama, "| seed jadwal terbaik:", best_seed)
    print("H1-H4:", hb, "| S1 (info):", s1, "| S2 (info):", s2)
    print(grid.to_string())


if __name__ == "__main__":
    main()
