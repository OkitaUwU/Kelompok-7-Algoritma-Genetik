"""Unit test fungsi fitness, operator, dan mesin AG. Jalankan: python -m unittest -v"""
import random
import unittest

from ga.data import load_data
from ga.engine import Params, run_ga
from ga.fitness import fitness, hard_breakdown, hard_violations
from ga.operators import (crossover_one_point, crossover_uniform, mutate,
                          random_chromosome, select_roulette, select_tournament)


class UjiFitness(unittest.TestCase):
    def setUp(self):
        self.d = load_data("data")
        # jadwal valid: sesi ke-i di slot i, ruang FT-05 (kapasitas 60) -> tidak ada bentrok
        self.valid = [(i, 4) for i in range(20)]

    def test_jadwal_valid_fitness_satu(self):
        self.assertEqual(hard_violations(self.valid, self.d), 0)
        self.assertEqual(fitness(self.valid, self.d), 1.0)

    def test_h1_dosen_bentrok(self):
        ch = list(self.valid)
        ch[13] = (0, 3)         # PWM IV-A (Efrans) satu slot dengan AP2 II-A (Efrans) di slot 0, ruang beda
        h1, h2, h3, h4 = hard_breakdown(ch, self.d)
        self.assertEqual((h1, h2, h3, h4), (1, 0, 0, 0))

    def test_h2_ruang_bentrok(self):
        ch = list(self.valid)
        ch[13] = (0, 4)         # dosen sama (Efrans) dan ruang FT-05 sama pada slot 0
        h1, h2, h3, h4 = hard_breakdown(ch, self.d)
        self.assertEqual((h1, h2), (1, 1))

    def test_h3_kelas_bentrok(self):
        ch = list(self.valid)
        ch[1] = (0, 4)          # SD II-A (Widiatry) bersama AP2 II-A (Efrans) di slot 0, ruang sama
        h1, h2, h3, h4 = hard_breakdown(ch, self.d)
        self.assertEqual((h1, h2, h3), (0, 1, 1))

    def test_h4_kapasitas(self):
        ch = list(self.valid)
        ch[10] = (10, 0)        # Basis Data II IV-A (46 peserta) pada FT-01 (kapasitas 30)
        self.assertEqual(hard_breakdown(ch, self.d)[3], 1)

    def test_rumus_fitness(self):
        ch = list(self.valid)
        ch[10] = (10, 0)
        self.assertAlmostEqual(fitness(ch, self.d), 1 / (1 + 1))


class UjiOperator(unittest.TestCase):
    def setUp(self):
        self.d = load_data("data")
        self.rng = random.Random(1)
        self.p1 = random_chromosome(self.d, self.rng)
        self.p2 = random_chromosome(self.d, self.rng)

    def test_panjang_dan_rentang_gen(self):
        for ch in (self.p1, self.p2):
            self.assertEqual(len(ch), 20)
            for slot, room in ch:
                self.assertTrue(0 <= slot < 25 and 0 <= room < 5)

    def test_crossover_menjaga_panjang_dan_gen(self):
        for cx in (crossover_one_point, crossover_uniform):
            c1, c2 = cx(self.p1, self.p2, self.rng)
            self.assertEqual((len(c1), len(c2)), (20, 20))
            for i in range(20):
                self.assertEqual({c1[i], c2[i]}, {self.p1[i], self.p2[i]})

    def test_mutasi_pm_nol_tidak_mengubah(self):
        self.assertEqual(mutate(self.p1, self.d, 0.0, self.rng), self.p1)

    def test_seleksi_mengembalikan_anggota_populasi(self):
        pop = [self.p1, self.p2]
        fit = [0.2, 0.8]
        self.assertIn(select_roulette(pop, fit, self.rng), pop)
        self.assertIn(select_tournament(pop, fit, self.rng), pop)


class UjiMesin(unittest.TestCase):
    def test_reprodusibel_dengan_seed_sama(self):
        d = load_data("data")
        p = Params(pop_size=30, generations=10)
        a, b = run_ga(d, p, 7), run_ga(d, p, 7)
        self.assertEqual(a.best, b.best)
        self.assertEqual(a.best_history, b.best_history)

    def test_fitness_terbaik_tidak_menurun_karena_elitisme(self):
        d = load_data("data")
        r = run_ga(d, Params(pop_size=30, generations=20), 3)
        self.assertTrue(all(y >= x for x, y in zip(r.best_history, r.best_history[1:])))


if __name__ == "__main__":
    unittest.main()
