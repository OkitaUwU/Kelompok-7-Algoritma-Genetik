# Optimasi Penjadwalan Kuliah dengan Algoritma Genetika (Tahap UTS)

AG dasar untuk *University Course Timetabling Problem* skala kecil:
**20 mata kuliah, 9 dosen, 5 ruang, 4 kelas mahasiswa, 5 hari x 5 slot waktu (25 slot)**.
Seluruh operator AG (inisialisasi, seleksi roulette wheel dan turnamen, crossover satu titik
dan uniform, mutasi, elitisme) ditulis sendiri tanpa library AG seperti DEAP atau PyGAD.

## Struktur

| Berkas / folder | Fungsi |
|---|---|
| `data/matkul.csv`, `dosen.csv`, `ruang.csv` | Data mata kuliah, dosen (slot yang dihindari), dan ruang |
| `ga/data.py` | Pemuatan data dan pemetaan indeks slot ke hari/jam |
| `ga/fitness.py` | Pelanggaran kendala keras H1-H4, fitness, informasi kendala lunak |
| `ga/operators.py` | Seleksi, crossover, mutasi, inisialisasi populasi |
| `ga/engine.py` | Loop evolusi, elitisme, pencatatan riwayat fitness |
| `run_uts.py` | Pengujian awal: 4 kombinasi operator x 10 run (seed 1-10), ekspor hasil |
| `buat_diagram_alir.py` | Membuat gambar diagram alir untuk laporan |
| `tests/test_fitness.py` | Unit test fungsi fitness, operator, dan mesin AG |
| `hasil/` | Keluaran: CSV, Excel, grafik konvergensi |

## Cara menjalankan

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python -m unittest discover -s tests -t . -v    # jalankan unit test
python run_uts.py                               # jalankan pengujian 10 run dan ekspor hasil
```

Hasil akan muncul di folder `hasil/`:
`jadwal_terbaik.xlsx` (daftar sesi, tabel hari x slot, jadwal per kelompok (semester-kelas), rekap run),
`jadwal_terbaik.csv`, `jadwal_hari_slot.csv`, `ringkasan_run.csv`,
`ringkasan_kombinasi.csv`, `konvergensi.png`, `konvergensi_utama.png`.

## Parameter bawaan

Populasi 100, 100 generasi, peluang crossover 0,8, peluang mutasi 0,05 per gen,
turnamen k = 3, elitisme 2 individu. Ubah di `ga/engine.py` (kelas `Params`).
Hasil bersifat reproduksibel karena setiap run memakai `random.Random(seed)`.

## Representasi dan fitness

Kromosom = daftar 20 gen; gen ke-i = pasangan `(slot, ruang)` untuk sesi mata kuliah ke-i,
dengan slot 0..24 (`slot = hari*5 + jam`) dan ruang 0..4.
`fitness = 1 / (1 + total pelanggaran kendala keras)`; jadwal valid bila fitness = 1.

Kendala keras: H1 dosen sama pada slot sama, H2 ruang sama pada slot sama,
H3 kelas mahasiswa sama pada slot sama, H4 jumlah peserta melebihi kapasitas ruang.
Kendala lunak (S1 preferensi waktu dosen, S2 jeda kelas) baru dilaporkan sebagai informasi.

## Catatan data

Mata kuliah, kode, kelas (semester-kelas), SKS, jumlah mahasiswa, dan dosen (koordinator mata kuliah)
diambil dari Jadwal Kuliah Prodi S-1 Teknik Informatika UPR Semester Genap 2025/2026 (revisi 2).
Kapasitas ruang dan preferensi waktu dosen adalah data simulasi. SKS hanya menjadi atribut data
(tiap sesi tetap menempati satu slot).
